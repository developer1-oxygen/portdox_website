	$.fbuilder.controls[ 'fradio' ]=function(){};
	$.extend(
		$.fbuilder.controls[ 'fradio' ].prototype, 
		$.fbuilder.controls[ 'ffields' ].prototype,
		{
			title:"Select a Choice",
			ftype:"fradio",
			layout:"one_column",
			required:false,
			choiceSelected:"",
			showDep:false,
			show:function()
				{
					this.choicesVal = ((typeof(this.choicesVal) != "undefined" && this.choicesVal !== null)?this.choicesVal:this.choices.slice(0));
					
					var l 		 = this.choices.length,
						str 	 = "",
						classDep = "";
					
					if ( typeof this.choicesDep == "undefined" || this.choicesDep == null )
						this.choicesDep = new Array();
					
					for (var i=0;i<l;i++)
					{
						if( typeof this.choicesDep[i] != 'undefined' )
							this.choicesDep[i] = $.grep(this.choicesDep[i],function(n){ return n != ""; });
						else
							this.choicesDep[i] = [];
						
						if( this.choicesDep[i].length )
							classDep = 'depItem';
					}

					for (var i=0;i<l;i++)
					{
						str += '<div class="'+this.layout+'"><label><input name="'+this.name+'" id="'+this.name+'" class="field '+classDep+' group '+((this.required)?" required":"")+'" value="'+$.fbuilder.htmlEncode(this.choicesVal[i])+'" vt="'+$.fbuilder.htmlEncode(this.choices[i])+'" type="radio" '+((this.choices[i]+' - '+this.choicesVal[i]==this.choiceSelected)?"checked":"")+'/> '+$.fbuilder.htmlDecode( this.choices[i] )+'</label></div>';
					}
					
					return '<div class="fields '+this.csslayout+'" id="field'+this.form_identifier+'-'+this.index+'"><label>'+this.title+''+((this.required)?"<span class='r'>*</span>":"")+'</label><div class="dfield">'+str+'<span class="uh">'+this.userhelp+'</span></div><div class="clearer"></div></div>';
				},
			showHideDep:function( toShow, toHide )
				{
					var me		= this,
						item 	= $( '#'+me.name+'.depItem' ),
						form_identifier = me.form_identifier,
						isHidden = (typeof toHide[ me.name ] != 'undefined'),
						result 	= [];
						
					try
					{
						item.each(function(i,e){
							if( typeof me.choicesDep[i] != 'undefined' && me.choicesDep[ i ].length )
							{
								var checked = e.checked;
								for( var j = 0, k = me.choicesDep[ i ].length; j < k; j++)
								{
									var dep = me.choicesDep[i][j]+form_identifier;
									if( isHidden )
									{
										if( typeof toShow[ dep ] != 'undefined' )
										{
											delete toShow[ dep ][ 'ref' ][ me.name ];
											if( $.isEmptyObject(toShow[ dep ][ 'ref' ]) )
											delete toShow[ dep ];
										}	
									}
									
									if( typeof toShow[ dep ] == 'undefined' )
									{
										if( checked && !isHidden )
										{
											$( '#'+dep ).closest( '.fields' ).show();
											$( '[id="'+dep+'"].ignore' ).removeClass( 'ignore' );
											toShow[ dep ] = { 'ref': {}};
											toShow[ dep ][ 'ref' ][ me.name ]  = 1;
											delete toHide[ dep ];
										}
										else
										{
											$( '#'+dep ).closest( '.fields' ).hide();
											$( '[id="'+dep+'"]:not(.ignore)' ).addClass( 'ignore' );
											toHide[ dep ] = {};
										}	
										result.push( dep );
									}	
								}
							}
						});
					}
					catch( e ){  }
					return result;
				},
			val:function()
				{
					var e = $( '[id="' + this.name + '"]:not(.ignore):checked' ), r = 0;
					if( e.length ) r = $.fbuilder.parseValStr( e.val() );
					return ( r != '""' ) ? r : 0;
				},
			setVal:function( v )
				{
					$( '[id="'+this.name+'"][vt="'+v+'"]' ).attr( 'CHECKED', true );
				}	
		}
	);