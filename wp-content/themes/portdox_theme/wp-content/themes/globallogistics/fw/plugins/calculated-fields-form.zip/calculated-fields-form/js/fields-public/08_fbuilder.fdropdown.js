	$.fbuilder.controls[ 'fdropdown' ]=function(){};
	$.extend(
		$.fbuilder.controls[ 'fdropdown' ].prototype,
		$.fbuilder.controls[ 'ffields' ].prototype,
		{
			title:"Select a Choice",
			ftype:"fdropdown",
			size:"medium",
			required:false,
			choiceSelected:"",
			showDep:false,
			show:function()
				{
					this.choicesVal = ((typeof(this.choicesVal) != "undefined" && this.choicesVal !== null)?this.choicesVal:this.choices.slice(0))
					
					var c	= this.choices,
						cv	= this.choicesVal,
						l 	= c.length,
						classDep = '',
						str = '';
					
					if ( typeof this.choicesDep == "undefined" || this.choicesDep == null )
						this.choicesDep = new Array();
					
					for (var i=0;i<l;i++)
					{
						if( typeof this.choicesDep[i] != 'undefined' )
							this.choicesDep[i] = $.grep(this.choicesDep[i],function(n){ return n != ""; });
						else
							this.choicesDep[i] = [];
						
						if( this.choicesDep[i].length )
							classDep = 'depItem';
					}
					
					for (var i=0;i<l;i++)
					{
						str += '<option '+((this.choiceSelected == c[i]+' - '+cv[i])?"selected":"")+' '+( ( classDep != '' ) ? 'class="'+classDep+'"' : '' )+' value="'+$.fbuilder.htmlEncode(cv[i])+'" vt="'+$.fbuilder.htmlEncode(c[i])+'" >'+c[i]+'</option>';
					}
					
					return '<div class="fields '+this.csslayout+'" id="field'+this.form_identifier+'-'+this.index+'"><label for="'+this.name+'">'+this.title+''+((this.required)?"<span class='r'>*</span>":"")+'</label><div class="dfield"><select id="'+this.name+'" name="'+this.name+'" class="field '+( ( classDep != '' ) ? ' depItemSel ' : '' )+this.size+((this.required)?" required":"")+'" >'+str+'</select><span class="uh">'+this.userhelp+'</span></div><div class="clearer"></div><div class="clearer"></div></div>';
				},
			showHideDep:function( toShow, toHide )
				{
					var me = this,
						item = $( '#'+me.name+'.depItemSel' ),
						form_identifier = me.form_identifier,
						isHidden = (typeof toHide[ me.name ] != 'undefined'),
						result = [];
		
					try
					{
						if( item.length )
						{
							var selected = item[0].selectedIndex;
							for( var i = 0, h = me.choices.length; i < h; i++ )
							{
								if( typeof me.choicesDep[i] != 'undefined' && me.choicesDep[ i ].length )
								{
									for( var j = 0, k = me.choicesDep[ i ].length; j < k; j++)
									{
										var dep = me.choicesDep[i][j]+form_identifier;
										if( isHidden )
										{
											if( typeof toShow[ dep ] != 'undefined' )
											{
												delete toShow[ dep ][ 'ref' ][ me.name ];
												if( $.isEmptyObject(toShow[ dep ][ 'ref' ]) )
												delete toShow[ dep ];
											}
										}
										
										if( typeof toShow[ dep ] == 'undefined' )
										{
											if( selected == i && !isHidden )
											{
												$( '#'+dep ).closest( '.fields' ).show();
												$( '[id="'+dep+'"].ignore' ).removeClass( 'ignore' );
												toShow[ dep ] = { 'ref': {}};
												toShow[ dep ][ 'ref' ][ me.name ]  = 1;
												delete toHide[ dep ];
											}
											else
											{
												$( '#'+dep ).closest( '.fields' ).hide();
												$( '[id="'+dep+'"]:not(.ignore)' ).addClass( 'ignore' );
												toHide[ dep ] = {};
											}
											result.push( dep );
										}	
									}	
								}
							}	
						}	
					}
					catch( e ){}
					return result;
				},
			val:function()
				{
					var e = $( '[id="' + this.name + '"]:not(.ignore)' ), r = 0;
					if( e.length ) r = $.fbuilder.parseValStr( e.val() );
					return ( r != '""' ) ? r : 0;
				},
			setVal:function( v )
				{
					$( '[id="'+this.name+'"] OPTION[vt="'+v+'"]' ).attr( 'SELECTED', true );
				}	
		}
	);